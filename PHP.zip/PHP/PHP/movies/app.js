require('dotenv').config();
const cors=require('cors');
const express = require('express');
require('./src/db/dbConnect.js');
const path = require('path');
const movieRouter = require('./src/routes/movie-router');
const usersRouter = require('./src/routes/usersRoute');


const app = express();

app.use(cors());

// app.use("/api", function(req, res, next){
//     res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
//     res.header('Access-Control-Allow-Headers', 'content-type');
//     next();
// });


app.use(express.static(path.join(__dirname, 'src/public')));
app.use(express.urlencoded({ extended: true }));

app.use(express.json());

// app.use("", function(req, res, next){
//     res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
//     next();
// });

//app.use(cors({origin: "http://localhost:4200"}));

// app.use("", function(req, res, next){
// 	res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
//   res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE');
//   res.header('Access-Control-Allow-Headers', 'Origin, XRequested-With, Content-Type, Accept');
// 	next();
// });


app.use("/api", movieRouter);
app.use("/api",usersRouter);

app.listen(process.env.PORT, () => {
    console.log(process.env.START_MESSAGE, process.env.PORT);
});