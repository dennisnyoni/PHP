
const Movie =require("../model/movieModel");

const movieData=function(movie, res){
    if (!movie) {
        //console.log("Movie not found");
        res.status(parseInt(process.env.RESOURCE_NOT_FOUND_STATUS_CODE))
            .json({message: process.env.MOVIE_NOT_FOUND_MESSAGE});
    }else{
        //console.log("artists: ",movie.artists);
        res.status(parseInt(process.env.OK_STATUS_CODE)).json(movie.artists)
    }
}

module.exports.getArtists = function (req,res){

    const movieId = req.params.movieId;

    Movie.findById(movieId)
        .then((data)=>movieData(data, res))
        .catch(err=>{
        res.status(parseInt(process.env.BAD_REQUEST_STATUS_CODE))
            .json(err);
    });

}

module.exports.addArtist = function (req,res){
    const movieId = req.params.movieId;
    const artist={
        name:req.body._name,
        yearStartedActing:req.body._yearStartedActing,
        _id:""
    }
    Movie.findById(movieId)
        .then(data=>artistData(data))
        .catch(err=>{
        res.status(parseInt(process.env.BAD_REQUEST_STATUS_CODE))
            .json(err);
    });

    const artistData = function(movie){
        if(!movie){
            res.status(parseInt(process.env.RESOURCE_NOT_FOUND_STATUS_CODE))
                .json({message:process.env.MOVIE_NOT_FOUND_MESSAGE});
        }else{
            artist._id +=movie.artists.length+1;
            movie.artists.push(artist);
            movie.save();
            res.status(parseInt(process.env.OK_STATUS_CODE)).json(artist);
        }
    }
}

module.exports.getOneArtist = function (req,res){
    const movieId = req.params.movieId;
    const artistId = req.params.artistId;

    Movie.findById(movieId)
        .then(data=>artistData(data))
        .catch(err=>{
        res.status(parseInt(process.env.BAD_REQUEST_STATUS_CODE)).json(err);
    });

   const artistData=function(movie){
        if(!movie){
            res.status(parseInt(process.env.RESOURCE_NOT_FOUND_STATUS_CODE)).json({message:process.env.MOVIE_NOT_FOUND_MESSAGE});
        }else if (!movie.artists){
            res.status(parseInt(process.env.RESOURCE_NOT_FOUND_STATUS_CODE)).json({message:process.env.MOVIE_NO_ARTIS_MESSAGE})
        }else{
            let artist = movie.artists.filter(artist=>artist._id==artistId)[0];
            res.status(parseInt(process.env.OK_STATUS_CODE)).json(artist);
        }
    }
}

module.exports.deleteOneArtist = function (req,res){

    const movieId = req.params.movieId;
    const artistId = req.params.artistId;
    //console.log("artist id: ",artistId);
    //console.log("movie id: ",movieId);

    Movie.findById(movieId)
        .then(data=>artist(data))
        .catch(error=>{res.status(parseInt(process.env.BAD_REQUEST_STATUS_CODE)).json(error);}

    )

    const artist = function(movie){
        const response = {
            status:parseInt(process.env.OK_STATUS_CODE),
            message:movie
        }
         if (!movie.artists){
            res.status(parseInt(process.env.RESOURCE_NOT_FOUND_STATUS_CODE))
                .json({message:process.env.NO_ARTIS_FOUND_MESSAGE});
        }
        else if (movie.artists){
            //movie.children.id(artist._id).remove();
            console.log("artistId: ",artistId);
            movie.artists.pull(artistId);
            let  artist = movie.artists.filter(artist=>artist._id==artistId)[0];

            movie.save();
            res.status(response.status).json(artist);
        }

    }
}