
const mongoose = require("mongoose");
const Movie = require("../model/movieModel");

//const movie = new Movie();
const getAll = function(req, res) {
    let offset = parseInt(process.env.DEFAULT_FIND_OFFSET,parseInt(process.env.RADIX));
    let count = parseInt(process.env.DEFAULT_FIND_COUNT, parseInt(process.env.RADIX)); //10;
    const maxCount = parseInt(process.env.DEFAULT_FIND_MAX_FIND_LIMIT, parseInt(process.env.RADIX)); //10;

    if (isNaN(offset) || isNaN(count)) {
        res
            .status(parseInt(process.env.BAD_REQUEST_STATUS_CODE))
            .json({ message: process.env.OFFSET_COUNT_ERROR_MESSAGE });
        return;
    }

    if (req.query && req.query.offset) {
        offset = parseInt(req.query.offset, parseInt(process.env.RADIX));
    }
    if (req.query && req.query.count) {
        offset = parseInt(req.query.count, parseInt(process.env.RADIX));
    }

    if (count > maxCount) {
        res
            .status(parseInt(process.env.BAD_REQUEST_STATUS_CODE))
            .json({ message: process.env.MAX_COUNT_ERROR + maxCount });
        return;
    }
    const response = { status: process.env.CREATED_STATUS_CODE, message: {} };
    Movie.find()
        .skip(offset)
        .limit(count)
        .then((movies) => sendResponse(response, res, movies))
        .catch((err)=>handleError(err, response, res));


};

const sendResponse = function ( response, res, body) {

    res.status(response.status).json(body);
}
const handleError = function (err, response,res) {
    //console.log("Error creating movie", err);

    response.status = parseInt(process.env.INTERNAL_ERROR_STATUS_CODE);
    response.message = err;
    sendResponse( response, res)
}

const addOne = function(req, res) {
    if(req.body){
        console.log("req.body is: ",req.body);
    }
    console.log("title: ",req.body._title);
    console.log("Year: ",req.body._year);
    console.log("marshalArt: ",req.body._marshalArt);
    const newMovie = {
        title: req.body._title,
        year: req.body._year,
        marshalArt: req.body._marshalArt,
        artists: req.body._artists,
    };
    console.log("movie ",newMovie);
    const response = { status:parseInt(process.env.CREATED_STATUS_CODE), message: {} };
    Movie.create(newMovie)
        .then((newMovie) => sendResponse( response, res, newMovie))
        .catch((err) => handleError(err,response,res))

};

const getOne = function(req, res) {
    //console.log("GET One Movie Controller");
    console.log(req.params.movieId);
    const movieId = req.params.movieId;

    Movie.findById(movieId).exec(function(err,movie) {
        const response = {
            status: parseInt(process.env.OK_STATUS_CODE),
            message: movie,
        };
        if (!movie) {
           // console.log("Movie id not found");
            res
                .status(parseInt(process.env.RESOURCE_NOT_FOUND_STATUS_CODE))
                .json({ message: process.env.MOVIE_NOT_FOUND_MESSAGE });
        } else {
            console.log("Found movie ", movie);
            res.status(response.status).json(response.message);
        }
    })

};
const movie= function(deletedMovie,res) {
    const response = {
        status: parseInt(process.env.NO_CONTENT_STATUS_CODE),
        message: deletedMovie,
    };
    if (!deleteMovie) {
        //console.log("Movie not found");
        response.status = parseInt(process.env.RESOURCE_NOT_FOUND_STATUS_CODE);
        response.message = {
            message: process.env.MOVIE_NOT_FOUND_MESSAGE,
        };
    }
    res.status(response.status).json(response.message);
}
const handleErrorDelete = function (err,res){
    //console.log("Error finding movie to delete ");
    res.status(parseInt(process.env.INTERNAL_ERROR_STATUS_CODE)).json(err);
}

const deleteMovie = function(req, res) {
    const movieId = req.params.movieId;
    Movie.findByIdAndDelete(movieId)
        .then(data=>movie(data))
        .catch((err)=> handleErrorDelete(err, res));
};

const save = function ( req,res,response, updatedMovie, err){
    if (err) {
        response.status = parseInt(process.env.INTERNAL_ERROR_STATUS_CODE);
        response.message = err;
        console.log(err);
    } else {
        response.status = parseInt(process.env.OK_STATUS_CODE);
        response.message = updatedMovie;
    }
    res.status(response.status).json(response.message);

}

const _partialUpdate = function(req, res, response, updatedMovie) {
    if (req.body.title)
        updatedMovie.title = req.body.title;
    if (req.body.year)
        updatedMovie.year = req.body.year;
    if (req.body.marshalArt)
        updatedMovie.marshalArt = req.body.marshalArt;
    //updatedMovie.artists = req.body.artists;
    updatedMovie.save((err, updatedMovie) => {
        save(req,res,response, updatedMovie, err);
    });

}

const _fullUpdate = function(req, res, response, updatedMovie) {
    updatedMovie.title = req.body.title;
    updatedMovie.year = req.body.year;
    updatedMovie.marshalArt = req.body.marshalArt;
    //updatedMovie.artists = req.body.artists;

    updatedMovie.save(function(err, updatedMovie) {
        save(req,res,response, updatedMovie);
    });
}

const _update = function(req, res, updateCallback) {
    let response = {
        status: parseInt(process.env.NO_CONTENT_STATUS_CODE),
        message: ""
    }

    console.log(process.env.FULL_UPDATE_ONE_LOG);
    let movieId = req.params.movieId;
    Movie.findById(movieId)
        .then(updatedMovie=>updateCallback(req, res, response, updatedMovie))
        .catch((err) => {
        response.status = parseInt(process.env.INTERNAL_ERROR_STATUS_CODE);
        response.message = err;
        console.log(err);
    });

}

const partialUpdateOne = function(req, res) {
    _update(req, res, _partialUpdate);
};

const fullUpdateOne = function(req, res) {
    _update(req, res, _fullUpdate);
};

module.exports = { getAll, getOne, addOne, deleteMovie, fullUpdateOne, partialUpdateOne };