
const mongoose = require("mongoose");   
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const {reject} = require("bcrypt/promises");
const User =  mongoose.model(process.env.USER_MODEL);


register = function (req, res) {
    console.log("User Register");


//genSalty
    bcrypt.genSalt(parseInt(process.env.NUMBER_OF_ROUNDS), function (err, saltValue) {
        if (err) {
            res.status(process.env.INTERNAL_SERVER_ERROR_STATUS_CODE);
            res.message = "Error";
        } else {
            bcrypt.hash(req.body.password, saltValue, function (err, password) {
                const newUser = {
                    name: req.body.name,
                    username: req.body.username,
                    password: password
                };
                User.create(newUser, function (err, result) {
                    const response = {
                        status: parseInt(process.env.OK_STATUS_CODE),
                        message: result };
                    if (err) {
                        console.log(process.env.ADD_ONE_ERROR_MESSAGE);
                        response.status = parseInt(process.env.SYSTEM_ERROR_STATUS_CODE);
                        response.message = err;
                    }
                    else{
                        response.message = process.env.LOGIN_SUCCESSFUL_MESSAGE;
                        const token = jwt.sign({username: newUser.username}, process.env.JWT_PASSWORD, {expiresIn: 3600});
                        response.message = {success:true, token:token};
                    }
                    res.status(response.status).json(response.message);
                })
            });
            //const passwordHash = bcrypt.hashSync(req.body.password, salt);           
        }

    });
    //const salt = bcrypt.genSaltSync(10);//10 is Number of Rounds

}

_checkUserExists = function (req) {
    console.log("Check User Exists");
    return new Promise((resolve, reject) =>  {
        console.log(req.body)
        const username = req.body.username;
        User.findOne({"username" : username})
            .then((user) => resolve(user))
            .catch((err)=>reject(err));
        console.log("done checking user");
    })

}

_checkPassword = function (req, user) {
if(req.body.password&&user){
    return new Promise((resolve, reject) => {
        console.log("check password");

        const password = req.body.password;
        bcrypt.compare(password, user.password)
            .then((user) => resolve(user))
            .catch((err) => reject(err));
    })
}

}

_generatetoken = function (user, response, res) {
    if(user){
        const token = jwt.sign({username: user.username},
            process.env.JWT_PASSWORD,
            {expiresIn: parseInt(process.env.TOKEN_EXPIRY_PERIOD)});
        response.message = {success:true, token:token};
        console.log("in token");
        res.status(process.env.OK_STATUS_CODE).json(response);
    }
}

_debugLog=function(message){
    if(JSON.parse(process.env.DEBUG_FLAG)){
        console.log(message);
    }
}

_handleError=function(error,response){
    response.status=parseInt(process.env.INTERNAL_ERROR_STATUS_CODE);
   const message = error;
    console.log(error)
}

login = function(req,res){

    _debugLog(process.env.LOGIN_CALLED_MESSAGE);

    const response = process.env.SUCCESS_RESPONSE;//_createDefaultResponse();


 User.findOne({ username: req.body.username})
     .then((user) => _checkUserExists(req))
     .then((user) => _checkPassword(req,user))
     .then((user) => _generatetoken(user,response, res))
     .catch((error) => _handleError(error,response))
     .finally(() => res.status(parseInt(process.env.OK_STATUS_CODE)).json());
}

module.exports = {
    addOne: register,
    login: login
}


