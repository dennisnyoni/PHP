const mongoose = require("mongoose");

const movieSchema = mongoose.Schema({
    title: { type: String, required: true },
    year: { type: Number, required: true },
    marshalArt: { type: String, required: true },
    artists: [],
});

//const Movie = mongoose.model(process.env.MOVIE_MODEL, movieSchema, "marshal_art");
const Movie = mongoose.model(process.env.MOVIE_MODEL, movieSchema);


module.exports = Movie;