import { Component } from '@angular/core';
import {Observable} from "rxjs";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Router} from "@angular/router";
import {LoginComponent} from "./login/login.component";
import {environment} from "../enviroments/environment";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = environment.title;


  constructor() {

  }

  handleLogout(): void{
    //this.login.reset();
  }


}
