import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {Artist} from "./movies.service";
import {environment} from "../enviroments/environment";

@Injectable({
  providedIn: 'root'
})
export class ArtistsService {

  movieId:string="";
  baseUrl:string = environment.MOVIES_BASE_URL;
  constructor(private http:HttpClient) { }

  getArtistes(movieId: string):Observable<any>{
    console.log("full path: "+this.baseUrl+"/"+movieId+"/"+environment.ARTISTS_URL);
    return this.http.get(this.baseUrl+"/"+movieId+"/"+environment.ARTISTS_URL);
  }

  getArtist(movieId: string,id: string):Observable<Artist>{
    return this.http.get<Artist>(this.baseUrl+"/"+movieId+"/"+environment.ARTISTS_URL+"/"+id);
  }

  createArtist(movieId: string,artist: Artist): Observable<Artist>{

    const result:Observable<Artist> =  this.http.post<Artist>(this.baseUrl+"/"+movieId+"/"+environment.ARTISTS_URL+"/",artist);
    console.log("artist: ",artist)
    return result;
  }

  updateArtist(movieId: string,id:string,Value:any):Observable<object>{
    return this.http.post(this.baseUrl+"/"+movieId+"/"+environment.ARTISTS_URL+"/"+id,Value)
  }

  deleteArtist(movieId: string,id:string):Observable<any>{
    return this.http.delete(this.baseUrl+"/"+movieId+"/"+environment.ARTISTS_URL+"/"+id);
  }
}
