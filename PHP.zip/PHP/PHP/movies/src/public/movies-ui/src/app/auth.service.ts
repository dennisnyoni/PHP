import { Injectable } from '@angular/core';
import {JwtHelperService} from "@auth0/angular-jwt";
import {environment} from "../enviroments/environment";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  #isLoggedIn: boolean = false;
  #name!: string;



  get token(): string { return localStorage.getItem(environment.TOKEN) as string }
  set token(token: string) { localStorage.setItem('token', token) }
  get name(): string { return this.#name }
  set name(name: string) { this.#name = name }
  get isLoggedIn(): boolean {if (this.token) return true;
  else
    return false;
  }
  set isLoggedIn(isLoggedIn: boolean) { this.#isLoggedIn = isLoggedIn; }

  constructor(private jwtService: JwtHelperService) { }

  removeToken(): void {
    localStorage.clear();
  }

}
