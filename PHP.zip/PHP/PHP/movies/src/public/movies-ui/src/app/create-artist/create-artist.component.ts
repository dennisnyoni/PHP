import {Component, Inject, Input} from '@angular/core';
import {Artist, MoviesService} from "../movies.service";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {Router} from "@angular/router";
import {ArtistsService} from "../artists.service";
import {environment} from "../../enviroments/environment";

@Component({
  selector: 'app-create-artist',
  templateUrl: './create-artist.component.html',
  styleUrls: ['./create-artist.component.css']
})
export class CreateArtistComponent {

  //@Input()
  id!:string;
  artist: Artist=new Artist();
  submitted = Boolean(environment.SUBMITTED_FALSE);
  message!:string;
  //data!:Movie;
  constructor(private artistService:ArtistsService, public dialogRef:MatDialogRef<CreateArtistComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any, private router: Router) {
    this.id = this.artistService.movieId;

    //console.log("Id is: ",this.data.id);
  }
  ngOnInit(){
   this.id = this.artistService.movieId;

   //console.log("Id is: ",this.data.id);
  }

  newArtist(){
    this.submitted = Boolean(environment.SUBMITTED_FALSE);
    this.artist = new Artist();
  }

  save():void{
    //this.movie.artists=[];
    //console.log("movie id: ",this.id)
    this.artistService.createArtist(this.data.id,this.artist)
      .subscribe({
        next:()=> this.message = environment.ARTISTE_CREATION_SUCCESS_MESSAGE,
        error:() => this.message = environment.ARTISTE_CREATION_FAILURE_MESSAGE

      });
    //console.log("artist: ",this.artist)
  }
  onSubmit(): void{
    this.submitted = Boolean(environment.SUBMITTED_TRUE);
    this.save();
    this.gotoList();
  }

  onClose(): void{
    this.dialogRef.close();
    this.gotoList();
  }

  gotoList(): void{
    this.router.navigate([environment.MOVIES_ROUTE]);
  }
}
