import {Component, Inject} from '@angular/core';
import {Movie, MoviesService} from "../movies.service";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {Router} from "@angular/router";
import {environment} from "../../enviroments/environment";

@Component({
  selector: 'app-create-movie',
  templateUrl: './create-movie.component.html',
  styleUrls: ['./create-movie.component.css']
})
export class CreateMovieComponent {

  //form!:FormGroup;
  movie: Movie = new Movie();
  submitted =Boolean(environment.SUBMITTED_FALSE);
  message!:string;
  //data!:Movie;
  constructor(private movieService:MoviesService, public dialogRef:MatDialogRef<CreateMovieComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any, private router: Router) {

  }
  ngOnInit(){
  }

  newMovie(){
    this.submitted = Boolean(environment.SUBMITTED_FALSE);
    this.movie = new Movie();
  }

  save():void{
    this.movie.artists=[];
    console.log("movie: ",this.movie)
    this.movieService.createMovie(this.movie)
      .subscribe({
        next:()=> this.message = environment.MOVIE_CREATION_SUCCESS_MESSAGE,
        error:() => this.message = environment.MOVIE_CREATION_FAILURE_MESSAGE

      });
    //console.log("movie: ",this.movie)
    this.newMovie();
  }
  onSubmit(): void{

    this.submitted = Boolean(environment.SUBMITTED_TRUE);
    this.save();
    this.newMovie();
    this.gotoList();
  }

  onClose(): void{
    this.dialogRef.close();
  }

  gotoList(): void{
    this.router.navigate([environment.MOVIES_ROUTE]);
  }
}
