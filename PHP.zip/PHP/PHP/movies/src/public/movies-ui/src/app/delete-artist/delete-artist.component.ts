import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-artist',
  templateUrl: './delete-artist.component.html',
  styleUrls: ['./delete-artist.component.css']
})
export class DeleteArtistComponent {

}
