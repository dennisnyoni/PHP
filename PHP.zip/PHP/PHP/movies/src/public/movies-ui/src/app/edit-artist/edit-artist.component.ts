import {Component, Inject} from '@angular/core';
import {Artist, Movie, MoviesService} from "../movies.service";
import {ActivatedRoute, Router} from "@angular/router";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {ArtistsService} from "../artists.service";
import {environment} from "../../enviroments/environment";

@Component({
  selector: 'app-edit-artist',
  templateUrl: './edit-artist.component.html',
  styleUrls: ['./edit-artist.component.css']
})
export class EditArtistComponent {

  id!: string;
  movieId!:string;
  artist: Artist = new Artist();
  submitted = Boolean(environment.SUBMITTED_FALSE);
  constructor(private artistService: ArtistsService, private route: ActivatedRoute,
              public dialogRef: MatDialogRef<EditArtistComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private router: Router) { }

  ngOnInit() {
    this.id = this.data.id;
    this.movieId = this.data.movieId;
    console.log("artist id: ",this.id);
    console.log("movie id: ",this.movieId);
    this.artistService.getArtist(this.movieId,this.id)
      .subscribe(data => {
        console.log(data);

        this.artist = data;
      }, error => console.log(error));
  }


  newArtist() {
    this.submitted = Boolean(environment.SUBMITTED_FALSE);
    this.artist = new Artist();
  }

  save() {
    this.movieId = this.data.movieId
    this.id = this.data.id;
    this.artistService.updateArtist(this.movieId,this.id, this.artist)
      .subscribe(data => alert(environment.ARTISTE_UPDATE_SUCCESS_MESSAGE),
          error => alert(environment.ARTISTE_UPDATE_FAILED_MESSAGE));
    this.artist = new Artist();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = Boolean(environment.SUBMITTED_TRUE);
    this.save();
    this.onClose();
  }

  onClose(){
    this.dialogRef.close();
  }

  gotoList() {
    this.onClose()
    this.router.navigate([environment.MOVIES_ROUTE]);
  }
}
