import { Component, Inject } from '@angular/core';
import {Movie, MoviesService} from "../movies.service";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {ActivatedRoute, Router} from "@angular/router";
import {environment} from "../../enviroments/environment";

@Component({
  selector: 'app-edit-movie',
  templateUrl: './edit-movie.component.html',
  styleUrls: ['./edit-movie.component.css']
})
export class EditMovieComponent {
  id!: string;
  movie: Movie = new Movie();
  submitted = Boolean(environment.SUBMITTED_FALSE);
  constructor(private userService: MoviesService, private route: ActivatedRoute,
              public dialogRef: MatDialogRef<EditMovieComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private router: Router) { }

  ngOnInit() {
    this.movie = new Movie();
    this.id = this.data.id;
    this.userService.getMovie(this.id)
      .subscribe(data => {
        console.log(data);
        this.movie = data;
      }, error => console.log(error));
  }

  newMovie() {
    this.submitted = Boolean(environment.SUBMITTED_FALSE);
    this.movie = new Movie();
  }

  save() {
    this.userService.updateMovie(this.id, this.movie)
      .subscribe(data => alert(environment.MOVIE_UPDATE_SUCCESS_MESSAGE), error => alert(environment.MOVIE_UPDATE_FAILED_MESSAGE));
    this.movie = new Movie();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = Boolean(environment.SUBMITTED_TRUE);
    this.save();
    this.onClose();
  }

  onClose(){
    this.dialogRef.close();
  }

  gotoList() {
    this.router.navigate([environment.MOVIES_ROUTE]);
  }
}
