import { Component } from '@angular/core';
import {environment} from "../../enviroments/environment";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  ImagePath: string;

  constructor() {

    this.ImagePath = environment.ImagePath;
  }

  ngOnInit() {
  }
}
