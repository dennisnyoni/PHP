import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {environment} from "../enviroments/environment";

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  baseUrl:string = environment.MOVIES_BASE_URL;
  constructor(private http:HttpClient) { }

  getMovies():Observable<any>{
    return this.http.get(this.baseUrl);
  }

  getMovie(id: string):Observable<Movie>{
    return this.http.get<Movie>(this.baseUrl+"/"+id);
  }

  createMovie(movie: any): Observable<Movie>{

  const result:Observable<Movie> =  this.http.post<Movie>(this.baseUrl,movie);
    console.log("movie: ",movie)
    return result;
  }

  updateMovie(id:string,Value:any):Observable<object>{
    return this.http.put(this.baseUrl+"/"+id,Value)
  }

  deleteMovie(id:string):Observable<any>{
    return this.http.delete(this.baseUrl+"/"+id);
  }
}

export class Movie{
  _id!:string
  _title!:string;
  _year!:number;
  _marshalArt!:string;
  _artists!:Artist[];

  get id(){
    return this._id;
  }
  set title(title:string){
    this._title =title;
  }

  get title(){
   return this._title;
  }

  set year(year:number){
    this._year =year;
  }

  get year(){
    return this._year;
  }
  set marshalArt(marshalArt:string){
    this._marshalArt =marshalArt;
  }
  get marshalArt(){
   return this._marshalArt;
  }

  set artists(artists:Artist[]){
    this._artists = artists;
  }

  get artists(){
    return this._artists;
  }
}

export  class Artist{
  _name!:string;
  _yearStartedActing!:number;

  set name(name:string){
    this._name = name;
  }

  get name(){
    return this._name
  }

  set yearStartedActing(year: number){
    this._yearStartedActing = year;
  }

  get yearStartedActing(){
     return this._yearStartedActing;
  }
}
