import { Component } from '@angular/core';
import {FormControl, FormGroup} from "@angular/forms";
import {UserDataService} from "../user-data.service";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  registerationform!: FormGroup;

  constructor(private userdataservice: UserDataService) {
  }


  ngOnInit(): void {
    this.registerationform = new FormGroup({
      name: new FormControl(),
      username: new FormControl(),
      password: new FormControl(),
      repeatpassword: new FormControl()
    });
  }

  onSubmit(form: FormGroup): void {
    console.log("form", form.value);
    this.userdataservice.registerUser(form.value).subscribe({
      next: (value) => {
        console.log(value);
      }, error: (err) => {
        console.log(err);
      }
    });

  }
}
