import { Injectable } from '@angular/core';
import {Observable} from "rxjs";
import {Credentials} from "./login/login.component";
import {HttpClient} from "@angular/common/http";
import {environment} from "../enviroments/environment";

@Injectable({
  providedIn: 'root'
})
export class UserDataService {

  private _baseUrl: string= environment.USERS_URL;

  constructor(private _http:HttpClient) {
  }

  public registerUser(user:User): Observable<User>{
    return this._http.post(this._baseUrl, user)as Observable<User>;
  }

  public loginUser(user:Credentials): Observable<Credentials>{
    const url:string= this._baseUrl + "/"+environment.LOGIN_PATH;
    console.log(user);
    return this._http.post(url, user)as Observable<Credentials>;
  }


}

export class User {
  name!: string;
  username!: string;
  password!: string;


  constructor(name: string, username: string, password: string) {
    this.name = name;
    this.username = username;
    this.password = password;
  }

}
