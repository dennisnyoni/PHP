backend runs on port 3535
frontend runs on port 4200

starts both frontend and backend
to start: npm start 


database name = movies
movies collection name = movies
users collection name = users

database is in gz format

Both frontend and backed 