import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {MoviesComponent} from "./movies/movies.component";
import {MovieDetailsComponent} from "./movie-details/movie-details.component";
import {CreateMovieComponent} from "./create-movie/create-movie.component";
import {DeleteMovieComponent} from "./delete-movie/delete-movie.component";
import {ArtistsComponent} from "./artists/artists.component";
import {ArtistDetailsComponent} from "./artist-details/artist-details.component";
import {CreateArtistComponent} from "./create-artist/create-artist.component";
import {DeleteArtistComponent} from "./delete-artist/delete-artist.component";
import {RegisterComponent} from "./register/register.component";
import {HomeComponent} from "./home/home.component";
import {LoginComponent} from "./login/login.component";

const routes: Routes = [
  {
    path:'',
    component:HomeComponent
  },
  {
    path:'movies',
    component:MoviesComponent
  },{
    path:'movie_details',
    component:MovieDetailsComponent
  },{
    path:'create_movie',
    component:CreateMovieComponent
  },{
    path:'delete_movie',
    component:DeleteMovieComponent
   },
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  //  {
  //   path:'artist_details',
  //   component:ArtistDetailsComponent
  // },{
  //   path:'create_artist',
  //   component:CreateArtistComponent
  // },{
  //   path:'delete_artist',
  //   component:DeleteArtistComponent
  // },
  {
    path:'register',
    component:RegisterComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
