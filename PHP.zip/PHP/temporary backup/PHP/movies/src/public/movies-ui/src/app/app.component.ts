import { Component } from '@angular/core';
import {Observable} from "rxjs";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Router} from "@angular/router";
import {LoginComponent} from "./login/login.component";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'Martial Arts Movies';
  imgUrl: any = './assets/rafiki/rafiki.png';
  private baseUrl = 'http://localhost:3535/api/movies/logout';


  constructor(private http: HttpClient, // private authenticationService: AuthenticationService,
              private router: Router) {

  }

  handleLogout(): void{
    //this.login.reset();
  }


}
