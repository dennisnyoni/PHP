import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {Artist} from "./movies.service";
import {environment} from "../enviroments/environment";

@Injectable({
  providedIn: 'root'
})
export class ArtistsService {

  movieId:string="";
  baseUrl:string = environment.MOVIES_BASE_URL;// "http://localhost:3535/api/movies";
  constructor(private http:HttpClient) { }

  getArtistes(movieId: string):Observable<any>{
    console.log("full path: "+this.baseUrl+"/"+movieId+"/artists");
    return this.http.get(this.baseUrl+"/"+movieId+"/artists");
  }

  getArtist(movieId: string,id: string):Observable<Artist>{
    return this.http.get<Artist>(this.baseUrl+"/"+movieId+"/artists/"+id);
  }

  createArtist(movieId: string,artist: Artist): Observable<Artist>{
    const headers = new HttpHeaders({'Access-Control-Allow-Origin':'*'});
    const result:Observable<Artist> =  this.http.post<Artist>(this.baseUrl+"/"+movieId+"/artists/",artist);//,{headers:headers});
    console.log("artist: ",artist)
    return result;
  }

  updateArtist(movieId: string,id:string,Value:any):Observable<object>{
    return this.http.post(this.baseUrl+"/"+movieId+"/artists/"+id,Value)
  }

  deleteArtist(movieId: string,id:string):Observable<any>{
    return this.http.delete(this.baseUrl+"/"+movieId+"/artists/"+id, {responseType:'json'});
  }
}
